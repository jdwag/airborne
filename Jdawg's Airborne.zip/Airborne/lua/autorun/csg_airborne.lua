local function AddPlayerModel( name, model )

	list.Set( "PlayerOptionsModel", name, model )
	player_manager.AddValidModel( name, model )
	
end

AddPlayerModel( "212th Airborne Officer", 			          "models/ab/airborne_off.mdl" )
AddPlayerModel( "212th Airborne Medic", 			          "models/ab/airborne_med.mdl" )
AddPlayerModel( "212th Airborne Trooper", 			          "models/ab/airborne_trp.mdl" )

